<?php

class Foo
{
    public function doAwesomeThings()
    {
        
    }
}
