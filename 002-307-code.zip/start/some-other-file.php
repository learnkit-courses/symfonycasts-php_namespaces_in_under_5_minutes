<?php

require 'Foo.php';
