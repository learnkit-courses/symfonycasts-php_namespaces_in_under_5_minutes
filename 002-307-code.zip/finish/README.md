PHP Namespaces in 120 Seconds Tutorial
======================================

Hiya! This repository houses the script and other items related to
the short SymfonyCasts screencast
[PHP Namespaces in 120 Seconds Tutorial](https://symfonycasts.com/screencast/php-namespaces-in-120-seconds).
