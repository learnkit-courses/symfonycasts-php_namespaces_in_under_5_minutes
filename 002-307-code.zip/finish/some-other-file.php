<?php

require 'Foo.php';

use Acme\Tools\Foo;

$foo = new Foo();

$foo->doAwesomeThings();
